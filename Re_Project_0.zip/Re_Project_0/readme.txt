Cool first project. Can't wait to do more this semesterwith Taylor Moede. 
https://plot.ly/javascript/click-events/ 
http://stackoverflow.com/questions/20644415/d3-appending-text-to-a-svg-rectangle
