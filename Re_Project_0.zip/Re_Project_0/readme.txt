https://plot.ly/javascript/click-events/ 
https://www.w3schools.com/html/html_styles.asp

Had a few classmates help me just because I was struggling a little bit. 

I wanted to go for a coral look since I did not have nay great visuals on my last project.

Part 1
	I was able to sucessfully upload Part 1's data.
	I had the wrong data length last time, I was just was not thinking clearly

Part 2
	I was able to create a graph correctly with the correct values

Part 3 & 4
	I was able to make it interactive this time. I did a tooltip.
	When you see the data point, which is a circle. It is dark cyan.
	When you hover over it is a neon turquoise. This allows you to see that you are on this point.
	When you click on it it becomes a colour imbetween the two other colours.
	Once clicked the X and Y values appear. 
	I combined these because it was going to be useful with the upcoming project. 

Part 5
	I did not do this part last time.
	I was able to successfully show all 4 datasets. 

I also modified the project0.css this time out of convenience.